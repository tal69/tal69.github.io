def CreateRequests (NumClusters, R, SetNumber, RequestsDraft):

    def GenerateCoordinates (zone):
        alpha = random.random() * 2* math.pi 
        r = random.random() * R
        x_cor = ClustersCoordinates[zone][0] + r * math.cos(alpha)
        y_cor = ClustersCoordinates[zone][1] + r * math.sin(alpha)

        return x_cor, y_cor

    ClustersCenters = "Clusters_" + str (NumClusters) + "_" + str (SetNumber) + ".csv"
    ClustersCoordinates = [[0 for i in range (2)] for j in range (NumClusters)]
    j = 0
    with open(ClustersCenters,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for row in spamreader:
            for k in range (2):
                ClustersCoordinates [j][k] = float (row [k])
            j = j + 1

    Requests = []
    for RDraft in RequestsDraft:
        zone = random.randint (0, NumClusters - 1)  #Each cluster has the same probability to yield the call
        x_cor, y_cor = GenerateCoordinates (zone)
        Requests.append ((RDraft[0], RDraft[1], RDraft[2], RDraft[3] ,zone , x_cor, y_cor))

    return Requests
        
        
def CreateRequestsDraft (TotalDemand, H) :

    j = 0
    lambda_hour = [0 for i in range (24)]
    with open("lambda_hour_norm.csv",'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for row in spamreader:
            lambda_hour [j] = TotalDemand * float (row [0])
            j = j + 1
    

    SimulationTimeMinutes = 0
    SimulationDay = 0
    SimulationHour = 0
    Requests = []

    for hourOfSimulation in range (H * 24):
        SimulationTimeMinutes = hourOfSimulation * 60
        SimulationDay = hourOfSimulation / 24
        SimulationHour = hourOfSimulation % 24
        
        RatesInTheHour = lambda_hour [SimulationHour]
        NumOfCalls = generateRandomPoissonNumber (RatesInTheHour)
        VecTimes = []
        for z in range (NumOfCalls):
            VecTimes.append (random.random ())
        VecTimes = sorted (VecTimes)
        ActualTimes = [SimulationTimeMinutes + 60 * time for time in VecTimes]
        x = 0
        for i in range (len(ActualTimes)) :
            Requests.append ((60 * VecTimes [i] - x, ActualTimes [i], ActualTimes [i] / 1440.0, SimulationHour))
            x = 60 * VecTimes [i]
            

    return lambda_hour, Requests
    

def generateRandomPoissonNumber (RatesInTheHour):
    L = math.exp (-RatesInTheHour)
    K = 0
    P = 1
    K = K + 1
    U = random.random ()
    P = P * U
    while P > L:
        K = K + 1
        U = random.random ()
        P = P * U

    return K-1

def generateRequestsUnified (TotalDemand, NumClusters, R, SetNumber, H, datasetType) :

    if datasetType == "Test":
        N = 42
    if datasetType == "Training":
        N = 1

    random.seed(N* TotalDemand)
    lambda_hour, RequestsDraft = CreateRequestsDraft (TotalDemand, H)
    random.seed(N* NumClusters * (R ** 2) * (SetNumber ** 3) * TotalDemand)
    Requests = CreateRequests (NumClusters, R, SetNumber, RequestsDraft)
    return Requests
        


import random
import csv
import math


