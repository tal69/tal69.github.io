This readme explains how to generate the streams of requests that we used for our simulations
The detailed results of the experiment are given in the file ElectronicAppendixBooking.docx and are not part of this readme. 


The python File CreatingRequests.py
===================================
The python file CreatingRequests.py contains a python function named generateRequestsUnified which creates the streams of requests. Its arguments are:  

TotalDemand -  the daily total demand, i.e. 64, 72 or 80.
NumClusters -  the number of clusters in the configuration, namely 8 (for urban and suburban configurations) or 72 (for the rural configuration)
R - the radius of the settlements (5 for urban, 10 for suburban and 2 for rural)  
SetNumber - serial replication number: 1, 2 or 3  
H - number of days to create requests for, that is 600 in the training stream and 6000 in the test stream 
datasetType - "Test" or "Training"

The function returns the generated requests. For example, the command: 
Requests = generateRequestsUnified (80, 8, 10, 2, 6000, "Test")
stores the requests that we used in the testing process of the instance D80Z8R10S2 in the "Requests" data structure.  

The returned data structure
***************************
It is a list of the requests. Each request is a tuple of 7 elements.
The first element is the inter-arrival time from the previous request (in minutes)
The second item is the arrival time of the request (in minutes). Note that 0 represents the beginning of the simulation
The third item is the day of which the request arrived. Note that the first day is denoted by 0
The fourth item is the hour of the day of which the request arrived. Note that the first hour in the day is denoted by 0
The fifth item is the zone that yielded the request, it is between 0 and (NumClusters -1)
The sixth item is the x coordinate of the request
The seventh item is the y coordinate of the request



Required input files for creating the requests
==============================================
There are 7 input files, all of which are of a csv format, that the CreatingRequests.py file uses for the creation of requests, and therefore are stored in the same folder. 
The first one, called "lambda_hour_norm", stores a vector with 24 items. Each item corresponds to fraction of the daily arrivals during each hour of the day, that is, it is the vector d(t) depicted in figure 2.

The other 6 files store the centers of the clusters.
The name of each of these files is of the structure "Clusters_" + <NumClusters> + "_" + <SetNumber>. 
That is, the file "Clusters_8_1" stores the centers of the eight clusters for the replication number 1. Note that the centers of the clusters in the urban and suburban configuration are the same, and so only 6 files (instead of 3 * 3 = 9) exist.  


  