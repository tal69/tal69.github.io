def CreateDataFiles (OptType, DataSetType, Nuser, widthuser, deltauser, patternuser):

    def checkTriangolarInEqulaity(TravelTimes):
        while (1):
            count = 0
            for i in range (NwithDepot):
                for j in list (set (range (NwithDepot)) - set ([i])):   
                    for k in list (set (range (NwithDepot)) - set ([i]) - set ([j])):
                        for t in range (T+1):
                            if TravelTimes [i][j][t] > TravelTimes [i][k][t] + TravelTimes [k][j][min (T, t + TravelTimes [i][k][t])]:
                                TravelTimes [i][j][t] = TravelTimes [i][k][t] + TravelTimes [k][j][min(T, t + TravelTimes [i][k][t])]
                                count = count + 1

            if count == 0:
                break
                                
        
        return TravelTimes


    def checkTriangolarInEqulaityBasic(TravelTimesBasic):
        
        while (1):
            count = 0
            for i in range (NwithDepot):
                for j in list (set (range (NwithDepot)) - set ([i])):   
                    for k in list (set (range (NwithDepot)) - set ([i]) - set ([j])):

                        if TravelTimesBasic [i][j] > TravelTimesBasic [i][k] + TravelTimesBasic [k][j]:
                            TravelTimesBasic [i][j]  = TravelTimesBasic [i][k] + TravelTimesBasic [k][j]
                            count = count + 1

            if count == 0:
                break
                                
        
        return TravelTimesBasic


    def checkTriangolarInEqulaityStochastic(TravelTimesScenarios):

        for scenario in range (num_scenarios):

            TravelTimesScenarios [scenario] = checkTriangolarInEqulaityBasic(TravelTimesScenarios [scenario])

        return TravelTimesScenarios


    def returnTravelTime (i,j,t):
        cluster = Clusters [i][j] - 1
        int = 0
        
        while Intervals [int][0] <= t and int < 72:
            int = int + 1
            if Intervals [int][0] > t :
                int = int - 1
                break

        Distance = DistanceMatrix [i][j]
        TT = 0
        t1 = t
        while float(Distance) / float (speedclusterperiods [cluster][int]) > Intervals [int][1] - t1:        
            TT = TT + Intervals [int][1] - t1     
            Distance = Distance - float (speedclusterperiods [cluster][int]) * (Intervals [int][1] - t1)
            int = int + 1
            t1 = Intervals [int][0]

        TT = TT + float(Distance) / float (speedclusterperiods [cluster][int])
        return TT

    def returnTravelTimeScenario (i,j,t,scenario):
        cluster = Clusters [i][j] - 1
        int = 0
        

        while Intervals [int][0] <= t and int < 72:
            int = int + 1
            if Intervals [int][0] > t :
                int = int - 1
                break

        Distance = DistanceMatrix [i][j]
        TT = 0
        t1 = t

        while float(Distance) / float (speedclusterperiods [cluster][int] * Multipliers [z][scenario][int][cluster]) > Intervals [int][1] - t1:
            
            
            TT = TT + Intervals [int][1] - t1
            Distance = Distance - float (speedclusterperiods [cluster][int] * Multipliers [z][scenario][int][cluster]) * (Intervals [int][1] - t1)
            
            int = int + 1
            t1 = Intervals [int][0]

        TT = TT + float(Distance) / float (speedclusterperiods [cluster][int] * Multipliers [z][scenario][int][cluster])
        return TT


    if OptType not in ['DD-TD-TSP-STW' , 'TD-TSP-STW', 'DD-TSP-STW', 'TSP-STW']:
        return ("Invalid OptType")
    if DataSetType not in ['Training' , 'Test']:
        return ("Invalid dataset type")
    if Nuser not in [15,20,30,40]:
        return ("Invalid number of customers")
    if widthuser not in [100,50]:
        return ("Invalid width of time windows")
    if deltauser not in [70,90,98]:
        return ("Invalid value of delta")
    if patternuser not in ['A','B']:
        return ("Invalid pattern")

    import math
    import time
    import copy
    import csv
    import pickle


    f_myfile = open('MultipliersArgiliano.pickle', 'rb')
    Multipliers = pickle.load(f_myfile)
    f_myfile.close()
    
    num_scenarios = 60
    csvfile = "DictInstances" + ".csv"
    instanceNumber = dict ()
    with open(csvfile,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for row in spamreader:

            instanceNumber [(int (row [0]), int (row [1]), str(row [2]), int (row [3]) )] = int (row [4])


    D = dict ()
    z = 0
    for nActual1 in [15, 20,30,40]:
        for width1 in [100, 50]:
            for delta1 in [70,90,98]:
                for pattern1 in ['A','B']:
                    D [nActual1, delta1, pattern1, width1 ] = z
                    z = z + 1
            
        
    z = D [Nuser, deltauser, patternuser, widthuser]
    Datfile =str (Nuser) +"_" + str (deltauser)  + "_" + patternuser + "_" + str(widthuser) + "_" + str(instanceNumber[Nuser, deltauser, patternuser, widthuser ])  + ".txt"
    
    with open(Datfile, "r") as f:
        data = f.readlines()
     

    linenumber = 0
    NwithDepot = int (data [linenumber]. split() [0])
    
    DistanceMatrix = [[0 for i in range (NwithDepot)] for j in range (NwithDepot)]
    linenumber = linenumber + 1
    for i in range (linenumber , linenumber + NwithDepot):
        for j in range (NwithDepot):
            DistanceMatrix [i-1][j] = float (data [i]. split() [j])

    linenumber = linenumber + NwithDepot
    
    a = []
    b = []

    for i in range (linenumber , linenumber + NwithDepot):
        a.append ((i - linenumber , int (data [i]. split() [0]) ))
        b.append ((i - linenumber , int (data [i]. split() [1]) ))

    linenumber = linenumber + NwithDepot + 1
    

    Clusters = [[0 for i in range (NwithDepot+1)] for j in range (NwithDepot+1)]
    for i in range (linenumber , linenumber + NwithDepot+1):
        for j in range (NwithDepot+1):
            Clusters [i-linenumber][j] = int (data [i]. split() [j])

    linenumber = linenumber + NwithDepot + 1 + 1

    Intervals = []
    for i in range (linenumber, linenumber + 73):
        if i < linenumber + 72:
            Intervals.append ((int (data [i]. split() [0]), int (data [i]. split() [1])))
        else:
            Intervals.append ((int (data [i]. split() [0]), 2 * b [0][1]))

    #Intervals [len (Intervals ) - 1] [1] = 

    linenumber = linenumber + 73 + 1
    b_h_u_ij = [[0 for i in range (73)] for j in range (3)]
    for i in range (linenumber , linenumber + 3):
        for j in range (73):
            b_h_u_ij [i-linenumber][j] = float (data [i]. split() [j])

            
    Datfile = "new_Jams_" + str (deltauser) + "_C_" + str(patternuser)
    
    with open(Datfile, "r") as f:
        data = f.readlines()

    linenumber = 0
    deltaij = [[0 for i in range (73)] for j in range (3)]
    for i in range (linenumber , linenumber + 3):
        for j in range (73):
            deltaij [i-linenumber][j] = float ((data [i].replace (',','.')). split() [j])

    speedclusterperiods = [[0 for i in range (73)] for j in range (3)]
    for i in range (3):
        for j in range (73):
            speedclusterperiods [i][j] = b_h_u_ij [i][j] * deltaij [i][j]
            
    
    T = b[0][1]
    
    if OptType == 'DD-TD-TSP-STW' or OptType == 'DD-TSP-STW': 
        TravelTimes = [[[[0 for k in range(T+1)] for j in range (NwithDepot)] for i in range (NwithDepot)] for scenario in range(num_scenarios)]
        for scenario in range(num_scenarios):
            for i in range (NwithDepot):
                for j in range (NwithDepot):
                    for k in range(T+1):
                        TravelTimes [scenario][i][j][k] = int (math.ceil (returnTravelTimeScenario (i,j,k,scenario)))
                    
        for scenario in range(num_scenarios):
            TravelTimes [scenario] = checkTriangolarInEqulaity(TravelTimes[scenario])


        if DataSetType == 'Training' and OptType == 'DD-TD-TSP-STW':
            
            return (a,b,TravelTimes[:40])
        if DataSetType == 'Test' and OptType == 'DD-TD-TSP-STW':
            
            return (a,b,TravelTimes[40:])

        if OptType == 'DD-TSP-STW': 
            TravelTimesScenarios=[[[0  for j in range(Nuser + 1)] for i in range(Nuser + 1)] for p in range(num_scenarios)]
            for p in range(num_scenarios):
                for i in range(Nuser + 1):
                    for j in range(Nuser + 1):
                        SumT = 0
                        for k in range(T):
                            SumT = SumT + TravelTimes[p][i][j][k]
                        TravelTimesScenarios[p][i][j] = int(round(float(SumT) / float(T)))
            
            TravelTimesScenarios = checkTriangolarInEqulaityStochastic(TravelTimesScenarios)
            if DataSetType == 'Training':
                return (a,b, TravelTimesScenarios[:40])
            if DataSetType == 'Test':
                return (a,b, TravelTimesScenarios[40:])



    if OptType == 'TD-TSP-STW' or OptType == 'TSP-STW':
        TravelTimes = [[[0 for k in range(T+1)] for j in range (NwithDepot)] for i in range (NwithDepot)]
        for i in range (NwithDepot):
            for j in range (NwithDepot):
                for k in range(T+1):
                    TravelTimes [i][j][k] = int (math.ceil (returnTravelTime (i,j,k)))

        TravelTimes = checkTriangolarInEqulaity(TravelTimes)
        if OptType == 'TD-TSP-STW':
            return (a,b,TravelTimes)

        if OptType == 'TSP-STW':
            TravelTimesBasic = [[0 for j in range (NwithDepot)] for i in range (NwithDepot)]
            for i in range (NwithDepot):
                for j in range (NwithDepot):
                    sumT = 0
                    for k in range(T+1):
                        sumT = sumT + TravelTimes [i][j][k]
                    TravelTimesBasic [i][j] = int (round (float (sumT) / float (T+1)))

            TravelTimesBasic = checkTriangolarInEqulaityBasic(TravelTimesBasic)
            
            return (a,b,TravelTimesBasic)


        
    
    
    
