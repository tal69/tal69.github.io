import random
import pickle
periods = 73
num_scenarios = 60
num_instances = 48
random.seed (9)
maxlim = 1.2
minlim = 0.8
walk = 0.05
Clusters = 3
Multipliers = [[[[0 for c in range (Clusters)] for t in range (periods)] for j in range (num_scenarios)] for i in range (num_instances)]
#cv = input ('ok')
for i in range(num_instances):
    for j in range (num_scenarios):

        for c in range (Clusters):
            Multipliers [i][j][0][c] = minlim + (maxlim-minlim) * random.random ()
            for t in range (1, periods):
                probability = random.random ()
                if probability < 1.0 / 3:
                    x = -1
                else:
                    if probability < 2.0 / 3:
                        x = 0
                    else:
                        x = 1
                
                Multipliers [i][j][t][c] = min (maxlim, max (minlim, Multipliers [i][j][t-1][c] + walk * x))
                
f_myfile = open('MultipliersArgiliano.pickle', 'wb')
pickle.dump(Multipliers, f_myfile)
f_myfile.close()
