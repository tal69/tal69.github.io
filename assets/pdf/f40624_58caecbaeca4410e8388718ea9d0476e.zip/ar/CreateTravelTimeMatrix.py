def CreateMatrixesAndScenarios (Combination ,OptType ,DataSetType ) :

    factor_s = 24.0 / (len (Combination) - 1)

    if len (Combination) < 1:
        return ("Invalid Combination")

    if DataSetType == 'Training':
        num_scenarios_fin = 40
        CombScenarios = range (40)
    elif DataSetType == 'Test':
        num_scenarios_fin = 20
        CombScenarios = range(40,60)
    else:
        return ("Invalid dataset type")

    if OptType != 'DD-TD-TSP-STW' and OptType != 'TD-TSP-STW' and OptType != 'DD-TSP-STW' and OptType != 'TSP-STW':
        return ("Invalid Optimization type")
    
    import csv
    import math
    import pickle
    NwithDepot = 60
    NwithDeoptKnown = 19
    NumM = 21
    TravelTimesDep = [[[0 for j in range (NumM)] for k in range(NwithDepot)] for i in range (NwithDepot)]
    file = "MatrixBig" +".csv"
    line = 0
    with open(file,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for row in spamreader:
            Matrix = int(line / NwithDepot) #Find in what matrix you are
            LineN = line % NwithDepot #Find the correct line
            for j in range(NwithDepot):
                TravelTimesDep[LineN][j][Matrix ] = int(math.ceil(float(row[j])))
            line = line + 1

    file_to_open = "TravelTimesAllDays1Minute.pickle" 
    f_myfile = open(file_to_open, 'rb')
    TravelTimesAllDays = pickle.load(f_myfile)
    f_myfile.close()
    ReleventMatrix = [0, 3, 6, 9, 12, 15]
    RelevantMatrixScearios = [0, 1, 2, 3, 4, 5]

    num_scenarios = 60
    TravelTimesAllDays60Nodes = [[[[0 for t in range(6)] for j in range(NwithDepot)] for i in range(NwithDepot)] for p in range(num_scenarios)]

    for p in range(num_scenarios):
        for i in range(NwithDepot):
            for j in range(NwithDepot):
                for t in range(6):
                    VecToSort = [(z, TravelTimesDep[i][z][ReleventMatrix[t]]) for z in range(NwithDeoptKnown)]
                    VecToSort = sorted(VecToSort, key=lambda tup: tup[1])
                    i1 = VecToSort[0][0]
                    VecToSort = [(z, TravelTimesDep[j][z][ReleventMatrix[t]]) for z in range(NwithDeoptKnown)]
                    VecToSort = sorted(VecToSort, key=lambda tup: tup[1])
                    j1 = VecToSort[0][0]
                    if i1!=j1:
                        Ratio = float(TravelTimesAllDays[p][i1][j1][t]) / TravelTimesDep[i1][j1][ReleventMatrix[t]]
                    else:
                        Ratio = 1
                    TravelTimesAllDays60Nodes[p][i][j][t] = int(round(Ratio * TravelTimesDep[i][j][ReleventMatrix[t]]))


    n = 60
    TimeRes = 90
    NumM = 6
    TimeUnit = 1
    T = NumM * (TimeRes / TimeUnit)
    TravelTimesDep = [[[[0 for t in range(T)] for j in range(n)] for i in range(n)] for p in range(num_scenarios)]

    for p in range(num_scenarios):
        for i in range(n):
            for j in range(n):
                for k in range (NumM - 1):
                    for k1 in range(0,TimeRes / TimeUnit):
                        TravelTimesDep[p][i][j][(TimeRes / TimeUnit) * k + k1] = int(math.ceil(float(((TimeRes / TimeUnit - k1) * TravelTimesAllDays60Nodes[p][i][j][k] + k1 * TravelTimesAllDays60Nodes[p][i][j][ (k+1)])) / (TimeRes / TimeUnit)))
      

    for p in range(num_scenarios):
        for i in range(n):
            for j in range(n):
                for t in range(450, T):
                    TravelTimesDep[p][i][j][t] = TravelTimesAllDays60Nodes[p][i][j][5]


        
    
    TravelTimesCurExp=[[[[0 for k in range( T)] for j in range(len (Combination))] for i in range(len (Combination))] for p in range(num_scenarios_fin)]
                

    for p in range(num_scenarios_fin):
        for i in range(len (Combination)):
            for j in range(len (Combination)):
                for k in range(T):
                    TravelTimesCurExp[p][i][j][k] = int(math.ceil(factor_s * TravelTimesDep[CombScenarios[p]][Combination[i]][Combination[j]][min(T-1,k)]))
                    if i == j:
                        TravelTimesCurExp[p][i][j][k] = 0
                    if k>=1:
                        if TravelTimesCurExp[p][i][j][k] < TravelTimesCurExp[p][i][j][k-1] -1 :
                            TravelTimesCurExp[p][i][j][k] = TravelTimesCurExp[p][i][j][k-1] -1
    
    if OptType == 'DD-TD-TSP-STW':
        return TravelTimesCurExp

    if OptType == 'TD-TSP-STW':
        TravelTimesCur=[[[0 for k in range( T)] for j in range(len (Combination))] for i in range(len (Combination))]
        for i in range(len (Combination)):
            for j in range(len (Combination)):
                for k in range( T):
                    SumT = 0
                    for p in range(num_scenarios_fin):
                        SumT = SumT + TravelTimesCurExp[p][i][j][k]
                    TravelTimesCur[i][j][k] = int(round (float(SumT) / float(num_scenarios_fin)))

                    if k >=1:
                        if TravelTimesCur[i][j][k] < TravelTimesCur[i][j][k-1] - 1:
                            TravelTimesCur[i][j][k] = TravelTimesCur[i][j][k-1] - 1

        return TravelTimesCur

    if OptType == 'DD-TSP-STW':
        TravelTimesScenarios=[[[0  for j in range(len (Combination))] for i in range(len (Combination))] for p in range(num_scenarios_fin)]
        for p in range(num_scenarios_fin):
            for i in range(len (Combination)):
                for j in range(len (Combination)):
                    SumT = 0
                    for k in range(T):
                        SumT = SumT + TravelTimesCurExp[p][i][j][k]
                    TravelTimesScenarios[p][i][j] = int(round(float(SumT) / float(T)))
        return TravelTimesScenarios

    if OptType == 'TSP-STW':
        TravelTimesBasic=[[0  for j in range(len (Combination))] for i in range(len (Combination))]
        
        for i in range(len (Combination)):
            for j in range(len (Combination)):
                SumT = 0
                for p in range(num_scenarios_fin):
                    for k in range(T):
                        SumT = SumT + TravelTimesCurExp[p][i][j][k]
                TravelTimesBasic[i][j] = int(round(float(SumT) / float(T * num_scenarios_fin )))

        return TravelTimesBasic




